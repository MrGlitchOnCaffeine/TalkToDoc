"""
Natural language understanding for TalkToDoc.
Interprets basic health-related queries to identify symptoms, intent, or
information requests, per functional requirement 5 in the research
document.

This is a communication aid, not a diagnostic tool. The document is
explicit that the system does not provide formal medical diagnosis, so
this module only summarizes what the patient is communicating, it never
suggests a diagnosis or treatment.

Uses the OpenAI API, same as translation.py.

MOCK_MODE: if set to "true" in the env file, this uses simple keyword
matching instead of a real API call, so the rest of the app can be tested
for free, with no API key. Not a substitute for testing real NLU quality.
"""

import os
from dotenv import load_dotenv

load_dotenv("env")

MOCK_MODE = os.environ.get("MOCK_MODE", "").lower() == "true"

if not MOCK_MODE:
    from openai import OpenAI
    _client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

MODEL = "gpt-5.6-terra"

_MOCK_KEYWORDS = ["headache", "fever", "stomach", "cough", "dizzy", "pain", "vomit", "rash"]


def interpret_query(english_text):
    """
    english_text: the patient's message, already translated to English
    Returns a short plain-language summary of the likely symptoms, intent,
    or information request, to help the provider quickly understand what
    the patient needs. Not a diagnosis.
    """
    if MOCK_MODE:
        text_lower = english_text.lower()
        found = [word for word in _MOCK_KEYWORDS if word in text_lower]
        symptoms = ", ".join(found) if found else "an unspecified concern"
        return f"Patient reports {symptoms}. Requesting guidance. (Mock summary, no AI used.)"

    prompt = (
        "A patient sent the following message to a healthcare provider. "
        "In two sentences or less, summarize the likely symptoms, intent, "
        "or information request. Do not diagnose or suggest treatment, "
        "only summarize what the patient is communicating.\n\n"
        f"Message: {english_text}"
    )

    response = _client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content.strip()


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print('Usage: python nlu.py "english text"')
    else:
        print(interpret_query(sys.argv[1]))
