"""
TalkToDoc Flask application.
Wires together speech-to-text, translation, natural language understanding,
and text-to-speech into the patient-provider communication flow described
in the research document.

Two-step flow:
1. Patient submits input (text or audio) in their chosen language.
   The system transcribes it if needed, translates it to English, and
   summarizes the likely symptoms or intent for the provider.
2. Provider submits a reply in English. The system translates it back
   into the patient's language and generates spoken audio for it.

Provider authentication: all provider-side routes check for a
PROVIDER_TOKEN in the env file. The provider enters this token once
per browser session via the /provider-login page. It is stored in a
signed Flask session cookie, same as the patient's user_id. This is
not a full authentication system - it is a single shared credential
that closes the unauthenticated IDOR exposure on provider routes
without introducing a user accounts table or an auth framework.
Set PROVIDER_TOKEN to any long random string in the env file before
deploying with real patient data.

Audio cleanup: preview_*.wav files are cleaned up automatically after
/provider-response either promotes them (os.replace) or falls back to
a fresh synthesis. response_*.wav files are retained because the
patient needs to be able to play them back from /interaction/<id>.
A separate /cleanup-audio admin route deletes response audio older
than 30 days for disk management on long-running deployments.
"""

import os
import uuid
import glob
import functools
from datetime import datetime, timezone, timedelta

from dotenv import load_dotenv
from flask import Flask, request, jsonify, render_template, render_template_string, session, redirect, url_for

import database
import stt
import translation
import nlu
import tts

load_dotenv("env")

AUDIO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "audio")
PROVIDER_TOKEN = os.environ.get("PROVIDER_TOKEN", "")


def create_app():
    flask_app = Flask(__name__)
    flask_app.secret_key = os.environ["SECRET_KEY"]
    os.makedirs(AUDIO_DIR, exist_ok=True)
    return flask_app


app = create_app()

# Runs whether the app is started directly (python app.py, local development)
# or imported by a production server like gunicorn (Render deployment).
# Initialization code inside "if __name__ == '__main__'" only runs on a
# direct start, gunicorn never triggers it, so anything the app needs to
# work at all has to happen here instead.
database.init_db()
tts.preload_models()


# ── Provider authentication ───────────────────────────────────────────────────

def provider_required(f):
    """
    Decorator for provider-side routes. If PROVIDER_TOKEN is not set in
    the env file, the route is unprotected (preserving the existing
    behaviour for local development and demos). If it is set, the request
    must carry a matching token in the provider_session cookie, set by
    /provider-login. Returns 401 JSON for API routes, redirects to the
    login page for the /provider HTML route.
    """
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        if not PROVIDER_TOKEN:
            # Token not configured: unprotected, existing behaviour preserved.
            return f(*args, **kwargs)
        if session.get("provider_authenticated"):
            return f(*args, **kwargs)
        # HTML route gets a redirect; JSON routes get a 401.
        if request.accept_mimetypes.accept_html and not request.is_json:
            return redirect(url_for("provider_login"))
        return jsonify({"error": "provider authentication required"}), 401
    return decorated


@app.route("/provider-login", methods=["GET", "POST"])
def provider_login():
    """
    Simple token entry page. The provider enters the PROVIDER_TOKEN value
    from the env file. On success, sets provider_authenticated in the
    signed session cookie and redirects to /provider.
    """
    error = None
    if request.method == "POST":
        token = request.form.get("token", "").strip()
        if token and token == PROVIDER_TOKEN:
            session["provider_authenticated"] = True
            return redirect(url_for("provider_page"))
        error = "Incorrect token. Please try again."

    # Inline template so this fix does not require a new file in templates/.
    return render_template_string("""
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TalkToDoc — Provider Login</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
</head>
<body>
  <div class="app-shell">
    <div class="app-header provider">
      <div class="brand">
        <div class="brand-mark">
          <svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"
               stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7
                     8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8
                     8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48
                     0 0 1 8 8v.5z"/>
          </svg>
        </div>
        <div>
          <h1>TalkToDoc</h1>
          <span class="role-tag">Provider</span>
        </div>
      </div>
    </div>
    <main class="app-main" id="main-content">
      <div class="card" style="max-width:400px;margin:0 auto;">
        <h2>Provider access</h2>
        <p class="helper-text">Enter the provider token to continue.</p>
        {% if error %}
          <div class="status-banner error">{{ error }}</div>
        {% endif %}
        <form method="post">
          <label for="token">Access token</label>
          <input type="password" id="token" name="token"
                 placeholder="Enter provider token" autocomplete="current-password">
          <button type="submit" class="btn btn-provider" style="margin-top:16px;width:100%">
            Continue
          </button>
        </form>
      </div>
    </main>
  </div>
</body>
</html>
    """, error=error)


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_current_user_id(language):
    """
    Returns the user_id for the current browser session, creating a new
    user and session record the first time this browser is seen. This is
    what keeps a patient's messages tied to the same person instead of
    creating a brand new anonymous patient on every single submission.
    """
    if "user_id" not in session:
        user_id = database.add_user(name="Patient", preferred_language=language, role="patient")
        session_id = database.add_session(
            user_id=user_id,
            start_time=datetime.now(timezone.utc).isoformat(),
        )
        session["user_id"] = user_id
        session["session_id"] = session_id

    return session["user_id"]


def _cleanup_preview(interaction_id):
    """
    Deletes the preview audio file for an interaction if it still exists.
    Called after /provider-response either promotes the file (os.replace)
    or falls back to fresh synthesis - in the fresh-synthesis path the
    preview file is left behind unused, so we clean it here.
    """
    preview_path = os.path.join(AUDIO_DIR, f"preview_{interaction_id}.wav")
    try:
        if os.path.exists(preview_path):
            os.remove(preview_path)
    except OSError:
        pass  # If the remove fails, it is not worth surfacing as an error.


# ── Patient routes ────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("patient.html", languages=translation.SUPPORTED_LANGUAGES)


@app.route("/transcribe", methods=["POST"])
def transcribe_only():
    """
    Transcribes an audio recording without saving anything or translating
    it. Used by the transcript review step, so the patient can see and
    edit what was heard before it becomes the message actually sent to
    the provider. Nothing here touches the database.
    """
    language = request.form.get("language")
    if not language or language.lower() not in translation.SUPPORTED_LANGUAGES:
        return jsonify({"error": f"language must be one of {translation.SUPPORTED_LANGUAGES}"}), 400
    language = language.lower()

    audio_file = request.files.get("audio")
    if not audio_file:
        return jsonify({"error": "provide an audio file"}), 400

    temp_path = os.path.join(AUDIO_DIR, f"transcribe_{uuid.uuid4().hex}.wav")
    audio_file.save(temp_path)
    try:
        patient_text = stt.transcribe_audio(temp_path, language)
    finally:
        os.remove(temp_path)

    return jsonify({"patient_text": patient_text})


@app.route("/patient-input", methods=["POST"])
def patient_input():
    language = request.form.get("language")
    if not language or language.lower() not in translation.SUPPORTED_LANGUAGES:
        return jsonify({"error": f"language must be one of {translation.SUPPORTED_LANGUAGES}"}), 400
    language = language.lower()

    text = request.form.get("text")
    audio_file = request.files.get("audio")

    if not text and not audio_file:
        return jsonify({"error": "provide either text or audio"}), 400

    if audio_file:
        temp_path = os.path.join(AUDIO_DIR, f"upload_{uuid.uuid4().hex}.wav")
        audio_file.save(temp_path)
        try:
            patient_text = stt.transcribe_audio(temp_path, language)
        finally:
            os.remove(temp_path)
    else:
        patient_text = text

    english_text = translation.translate(patient_text, language, "english")
    nlu_summary = nlu.interpret_query(english_text)

    user_id = get_current_user_id(language)
    interaction_id = database.add_interaction(
        user_id=user_id,
        input_text=patient_text,
        detected_language=language,
        translated_text=english_text,
        nlu_summary=nlu_summary,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )

    return jsonify({
        "interaction_id": interaction_id,
        "patient_text": patient_text,
        "translated_text": english_text,
        "nlu_summary": nlu_summary,
    })


@app.route("/interaction/<interaction_id>")
def get_interaction(interaction_id):
    interaction = database.get_interaction(interaction_id)
    if not interaction:
        return jsonify({"error": "interaction not found"}), 404

    audio_filename = f"response_{interaction_id}.wav"
    audio_path = os.path.join(AUDIO_DIR, audio_filename)
    interaction["audio_url"] = f"/static/audio/{audio_filename}" if os.path.exists(audio_path) else None

    return jsonify(interaction)


@app.route("/history")
def history():
    if "user_id" not in session:
        return jsonify([])
    return jsonify(database.get_interactions_for_user(session["user_id"]))


@app.route("/end-session", methods=["POST"])
def end_session_route():
    if "session_id" in session:
        database.end_session(session["session_id"], datetime.now(timezone.utc).isoformat())
    session.clear()
    return jsonify({"status": "ended"})


# ── Provider routes (all protected by @provider_required) ─────────────────────

@app.route("/provider")
@provider_required
def provider_page():
    return render_template("provider.html")


@app.route("/preview-response", methods=["POST"])
@provider_required
def preview_response():
    """
    Runs the exact same translate + synthesize pipeline as /provider-response,
    so the provider can read and hear precisely what the patient will receive
    before committing. Unlike /provider-response, this never touches the
    database. The preview audio file is cleaned up automatically by
    /provider-response regardless of which code path it takes.
    """
    interaction_id = request.form.get("interaction_id")
    response_text = request.form.get("response_text")

    if not interaction_id or not response_text:
        return jsonify({"error": "interaction_id and response_text are required"}), 400

    interaction = database.get_interaction(interaction_id)
    if not interaction:
        return jsonify({"error": "interaction not found"}), 404

    patient_language = interaction["detected_language"]
    translated_response = translation.translate(response_text, "english", patient_language)

    audio_filename = f"preview_{interaction_id}.wav"
    audio_path = os.path.join(AUDIO_DIR, audio_filename)
    tts.synthesize_speech(translated_response, patient_language, audio_path)

    return jsonify({
        "translated_response": translated_response,
        "audio_url": f"/static/audio/{audio_filename}",
    })


@app.route("/provider-response", methods=["POST"])
@provider_required
def provider_response():
    interaction_id = request.form.get("interaction_id")
    response_text = request.form.get("response_text")
    cached_translation = request.form.get("translated_response")
    reuse_audio = request.form.get("reuse_audio") == "true"

    if not interaction_id or not response_text:
        return jsonify({"error": "interaction_id and response_text are required"}), 400

    interaction = database.get_interaction(interaction_id)
    if not interaction:
        return jsonify({"error": "interaction not found"}), 404

    patient_language = interaction["detected_language"]
    audio_filename = f"response_{interaction_id}.wav"
    audio_path = os.path.join(AUDIO_DIR, audio_filename)
    preview_path = os.path.join(AUDIO_DIR, f"preview_{interaction_id}.wav")

    if cached_translation and reuse_audio and os.path.exists(preview_path):
        translated_response = cached_translation
        os.replace(preview_path, audio_path)
        # preview file was promoted via os.replace so it no longer exists;
        # _cleanup_preview is a no-op here but called for consistency.
    else:
        translated_response = translation.translate(response_text, "english", patient_language)
        tts.synthesize_speech(translated_response, patient_language, audio_path)
        # preview file (if one existed from a prior Preview click) was not
        # promoted and is now orphaned; delete it.
        _cleanup_preview(interaction_id)

    database.update_interaction_response(interaction_id, response_text, translated_response)

    return jsonify({
        "translated_response": translated_response,
        "audio_url": f"/static/audio/{audio_filename}",
    })


@app.route("/pending-interactions")
@provider_required
def pending_interactions():
    return jsonify(database.get_pending_interactions())


@app.route("/completed-interactions")
@provider_required
def completed_interactions():
    return jsonify(database.get_completed_interactions())


@app.route("/patient-history/<user_id>")
@provider_required
def patient_history(user_id):
    """
    All of one patient's interactions, for the provider workspace's
    conversation history panel. Distinct from /history: that route looks
    up the current browser session, which only works for patients viewing
    their own messages. The provider needs to look up by explicit user_id.
    """
    return jsonify(database.get_interactions_for_user(user_id))


@app.route("/cleanup-audio", methods=["POST"])
@provider_required
def cleanup_audio():
    """
    Deletes response_*.wav files older than 30 days. Intended for
    long-running deployments where response audio accumulates on disk.
    Call this from a cron job or a scheduled task; it does not run
    automatically. Returns the number of files deleted and their
    total size freed in bytes.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=30)
    deleted_count = 0
    freed_bytes = 0

    for path in glob.glob(os.path.join(AUDIO_DIR, "response_*.wav")):
        try:
            mtime = datetime.fromtimestamp(os.path.getmtime(path), tz=timezone.utc)
            if mtime < cutoff:
                freed_bytes += os.path.getsize(path)
                os.remove(path)
                deleted_count += 1
        except OSError:
            pass

    return jsonify({
        "deleted": deleted_count,
        "freed_bytes": freed_bytes,
    })


if __name__ == "__main__":
    is_production = os.environ.get("ENVIRONMENT") == "production"
    app.run(debug=not is_production, host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
