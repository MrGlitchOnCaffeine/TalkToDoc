---
title: TalkToDoc
emoji: 🩺
colorFrom: green
colorTo: gray
sdk: docker
app_port: 7860
---

# TalkToDoc

A multilingual communication tool that helps patients and healthcare
providers understand each other across English, Yoruba, Hausa, Igbo, and
Nigerian Pidgin. Built for rural Nigerian healthcare settings where
doctor shortages and language barriers contribute to misdiagnosis and
communication breakdowns.

This Space runs the full application: speech-to-text, translation,
symptom summarization, and text-to-speech, in the patient's own
language.

Requires OPENAI_API_KEY, SECRET_KEY, and DATABASE_URL to be set as
secrets in this Space's settings.
