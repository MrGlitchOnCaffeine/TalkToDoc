"""
Database access layer for TalkToDoc.
Handles both SQLite (local development) and PostgreSQL (production) through
a single shared query interface. The only difference between the two is how
get_connection() builds the connection object; every function above that is
identical regardless of which database is running underneath.

Connection management: every public function in this module uses the
_connection() context manager (not get_connection() directly). That
context manager commits on success, rolls back on exception, and always
closes the connection before returning control. The bare
`with get_connection() as conn:` pattern that psycopg2 and sqlite3 both
support commits/rolls back correctly but never closes the connection,
which leaks file handles against SQLite and exhausts the Postgres
connection pool in production over time.
"""

import os
import contextlib

from dotenv import load_dotenv

load_dotenv("env")

DATABASE_URL = os.environ.get("DATABASE_URL")


def get_connection():
    """
    Returns a raw database connection. Callers should use _connection()
    instead, which wraps this and guarantees the connection is closed.
    """
    if DATABASE_URL:
        import psycopg2
        import psycopg2.extras
        conn = psycopg2.connect(DATABASE_URL, cursor_factory=psycopg2.extras.RealDictCursor)
        return conn
    else:
        import sqlite3
        conn = sqlite3.connect(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "talktodoc.db")
        )
        conn.row_factory = sqlite3.Row
        return conn


@contextlib.contextmanager
def _connection():
    """
    Context manager that opens a connection, yields it, commits on clean
    exit, rolls back on exception, and always closes. Use this everywhere
    instead of `with get_connection() as conn:`.
    """
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _run(connection, sql, params=()):
    cursor = connection.cursor()
    cursor.execute(sql, params)
    return cursor


def _placeholder():
    """
    SQLite uses ? for bind parameters; psycopg2 uses %s.
    Returns the right one for whichever database is active.
    """
    return "%s" if DATABASE_URL else "?"


def init_db():
    schema_file = "schema_postgres.sql" if DATABASE_URL else "schema.sql"
    schema_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), schema_file)
    with open(schema_path) as f:
        schema = f.read()
    with _connection() as conn:
        if DATABASE_URL:
            for statement in schema.split(";"):
                stmt = statement.strip()
                if stmt:
                    _run(conn, stmt)
        else:
            conn.executescript(schema)


def add_user(name, preferred_language, role):
    p = _placeholder()
    with _connection() as conn:
        if DATABASE_URL:
            cursor = _run(
                conn,
                f"INSERT INTO app_user (name, preferred_language, role) VALUES ({p}, {p}, {p}) RETURNING id",
                (name, preferred_language, role),
            )
            return cursor.fetchone()["id"]
        else:
            cursor = _run(
                conn,
                f"INSERT INTO app_user (name, preferred_language, role) VALUES ({p}, {p}, {p})",
                (name, preferred_language, role),
            )
            return cursor.lastrowid


def add_session(user_id, start_time):
    p = _placeholder()
    with _connection() as conn:
        if DATABASE_URL:
            cursor = _run(
                conn,
                f"INSERT INTO session (user_id, start_time) VALUES ({p}, {p}) RETURNING id",
                (user_id, start_time),
            )
            return cursor.fetchone()["id"]
        else:
            cursor = _run(
                conn,
                f"INSERT INTO session (user_id, start_time) VALUES ({p}, {p})",
                (user_id, start_time),
            )
            return cursor.lastrowid


def end_session(session_id, end_time):
    p = _placeholder()
    with _connection() as conn:
        _run(
            conn,
            f"UPDATE session SET end_time = {p} WHERE id = {p}",
            (end_time, session_id),
        )


def add_interaction(user_id, input_text, detected_language, translated_text,
                    nlu_summary, timestamp):
    p = _placeholder()
    sql = (
        f"INSERT INTO interaction "
        f"(user_id, input_text, detected_language, translated_text, nlu_summary, timestamp) "
        f"VALUES ({p}, {p}, {p}, {p}, {p}, {p})"
    )
    params = (user_id, input_text, detected_language, translated_text, nlu_summary, timestamp)
    with _connection() as conn:
        if DATABASE_URL:
            cursor = _run(conn, sql.replace(")", " RETURNING id)", 1), params)
            return cursor.fetchone()["id"]
        else:
            cursor = _run(conn, sql, params)
            return cursor.lastrowid


def get_interaction(interaction_id):
    p = _placeholder()
    with _connection() as conn:
        cursor = _run(
            conn,
            f"SELECT * FROM interaction WHERE id = {p}",
            (interaction_id,),
        )
        row = cursor.fetchone()
        return dict(row) if row else None


def update_interaction_response(interaction_id, provider_response, translated_response):
    p = _placeholder()
    with _connection() as conn:
        _run(
            conn,
            f"UPDATE interaction SET provider_response = {p}, translated_response = {p} WHERE id = {p}",
            (provider_response, translated_response, interaction_id),
        )


def get_interactions_for_user(user_id):
    p = _placeholder()
    with _connection() as conn:
        cursor = _run(
            conn,
            f"SELECT * FROM interaction WHERE user_id = {p} ORDER BY timestamp",
            (user_id,),
        )
        return [dict(row) for row in cursor.fetchall()]


def get_pending_interactions():
    with _connection() as conn:
        cursor = _run(
            conn,
            "SELECT * FROM interaction WHERE provider_response IS NULL ORDER BY timestamp",
        )
        return [dict(row) for row in cursor.fetchall()]


def get_completed_interactions():
    with _connection() as conn:
        cursor = _run(
            conn,
            "SELECT * FROM interaction WHERE provider_response IS NOT NULL ORDER BY timestamp DESC",
        )
        return [dict(row) for row in cursor.fetchall()]
