"""
Speech-to-text for TalkToDoc.
Converts a patient's spoken audio into text using a local Whisper model.
Language is passed in from the manual language selector, not auto-detected.
"""

import whisper

_model = None

# Maps the app's language selection to Whisper's language codes.
# Whisper supports Yoruba ("yo") and Hausa ("ha") natively.
# Igbo has no Whisper language code, so it falls back to English,
# same as Pidgin. Both are close enough to romanized Latin script
# that Whisper can still produce a usable transcription.
LANGUAGE_MAP = {
    "english": "en",
    "yoruba": "yo",
    "hausa": "ha",
    "igbo": "en",
    "pidgin": "en",
}


def _get_model():
    global _model
    if _model is None:
        _model = whisper.load_model("base")
    return _model


def transcribe_audio(audio_path, language=None):
    """
    audio_path: path to an audio file (wav, mp3, m4a, etc.)
    language: one of "english", "yoruba", "hausa", "igbo", "pidgin"
    Returns the transcribed text.
    """
    model = _get_model()
    whisper_language = LANGUAGE_MAP.get(language.lower()) if language else None
    result = model.transcribe(audio_path, language=whisper_language)
    return result["text"].strip()


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python stt.py <audio_file> [language]")
    else:
        audio_file = sys.argv[1]
        selected_language = sys.argv[2] if len(sys.argv) > 2 else None
        print(transcribe_audio(audio_file, selected_language))
